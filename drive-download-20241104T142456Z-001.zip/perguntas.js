criaCartao(
    'Programação',
    'O que é HTML?',
    'HTML é uma linguagem de marcação utilizada na construção de páginas na Web.'
)

criaCartao(
    'Filme',
    'Qual o filme com maior bilheteria do mundo',
    'Avatar'
)

criaCartao(
    'Jogos',
    'Qual ano foi lançado Minecraft?',
    '2011'
)

criaCartao(
    'Matemática II',
    'Qual aplicativo utilizamos nas aulas de Programação - Matemática II?',
    'Visual Studio Code'
)

criaCartao(
    'Matemática II',
    'Qual aplicativo utilizamos nas aulas de Programação - Matemática II?',
    'Visual Studio Code'
)